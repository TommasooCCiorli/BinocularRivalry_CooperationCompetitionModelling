function[regional_frequencies] = fcn_extract_frequencies(TS_CELL, TR, filter_low, filter_high)
% INPUTS:
% TS_CELL is a cell array, containing N-by-T matrix of BOLD signals with N regions and T timepoints
% each cell will be processed separately, if more than one (eg each might be a subject)
% TR is the sampling rate of the BOLD data (in seconds)
% filter_low and filter_high are the ends of the bandpass filter (in Hz)
%
% OUTPUTS:
% regional_frequencies: regional frequency of each region (in Hz)
%
% Original code from Gustavo Deco and Yonatan Sanz Perl; reformatted by Andrea Luppi
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


NSUB = numel(TS_CELL);
[NPARCELLS, Tmax] = size(TS_CELL{1});

%Filter
fnq=1/(2*TR);                 % Nyquist frequency
Wn=[filter_low/fnq filter_high/fnq];         % butterworth bandpass non-dimensional frequency
k=2;                          % 2nd order butterworth filter
[bfilt,afilt]=butter(k,Wn);   % construct the filter
Isubdiag = find(tril(ones(NPARCELLS),-1));

%%%%
fce1=zeros(NSUB,NPARCELLS,NPARCELLS);

for sub=1:NSUB
    %sub
   
    ts=TS_CELL{sub}(:,1:Tmax);

    TT=Tmax;
    tss=zeros(NPARCELLS,Tmax);
    Ts = TT*TR;
    freq = (0:TT/2-1)/Ts;
    nfreqs=length(freq);
    
    for seed=1:NPARCELLS
        x(seed,:)=detrend(ts(seed,:)-mean(ts(seed,:)));
        tss(seed,:)=filtfilt(bfilt,afilt,x(seed,:));
        pw = abs(fft(tss(seed,:)));
        PowSpect(:,seed,sub) = pw(1:floor(TT/2)).^2/(TT/TR);
    end
    fce1(sub,:,:)=corrcoef(tss','rows','pairwise');
end

Power_Areas=squeeze(mean(PowSpect,3));
for seed=1:NPARCELLS
    Power_Areas(:,seed)=gaussfilt(freq,Power_Areas(:,seed)',0.01);
end

[maxpowdata,index]=max(Power_Areas);
regional_frequencies = freq(index);
regional_frequencies(find(regional_frequencies==0))=mean(regional_frequencies(find(regional_frequencies~=0)));


