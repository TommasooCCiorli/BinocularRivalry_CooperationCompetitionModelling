function [sim_TS]=fcn_Hopf_simulate_BOLD_from_GEC(GEC,regionalFrequencies,sigma,T,TR);
% INPUTS:
% GEC is a (weighted) N-by-N magtrix of Generative Effective Connectivity
% (assume already scaled appropriately)
% regionalFrequencies is an N-size vector with the frequency (in Hz) of each node
% T is the number of timepoints
% TR is the sampling rate of the BOLD signal (in seconds)
% 
% OUTPUTS:
% sim_TS: N-by-T matrix of simulated BOLD signal
%
% Original code from Gustavo Deco and Yonatan Sanz Perl; reformatted by Andrea Luppi
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set up parameters
N= size(GEC,2);
sumC = repmat(sum(GEC,2),1,2); % for sum Cij*xj
dt=0.1*TR/2;
dsig = sqrt(dt)*sigma;
a=-0.02*ones(N,2);
omega = repmat(2*pi*regionalFrequencies',1,2); omega(:,1) = -omega(:,1);

sim_TS=zeros(T,N);
z = 0.1*ones(N,2); % --> x = z(:,1), y = z(:,2)
nn=0;

% discard first 3000 time steps
for t=0:dt:3000
    suma = GEC*z - sumC.*z; % sum(Cij*xi) - sum(Cij)*xj
    zz = z(:,end:-1:1); % flipped z, because (x.*x + y.*y)
    z = z + dt*(a.*z + zz.*omega - z.*(z.*z+zz.*zz) + suma) + dsig*randn(N,2);
end

% actual modeling
for t=0:dt:((T-1)*TR)
    suma = GEC*z - sumC.*z; % sum(Cij*xi) - sum(Cij)*xj
    zz = z(:,end:-1:1); % flipped z, because (x.*x + y.*y)
    z = z + dt*(a.*z + zz.*omega - z.*(z.*z+zz.*zz) + suma) + dsig*randn(N,2);
    if abs(mod(t,TR))<0.01
        nn=nn+1;
        sim_TS(nn,:)=z(:,1)';
    end
    sim_TS=sim_TS';
end
